public class VipMember extends Member {
    public VipMember (String nombre) {
        super(nombre);
    }

    @Override
    public void joinTournament() {

    }

    @Override
    public void organizeTournament() {

    }
}
