public class PremiumMember extends Member {
    public PremiumMember(String nombre) {
        super(nombre);
    }

    @Override
    public void joinTournament() {

    }

    @Override
    public void organizeTournament() {

    }
}

